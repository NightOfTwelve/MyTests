//
//  Music.h
//  BTAudioQPlayer
//
//  Created by Gary on 12-10-7.
//  Copyright (c) 2012年 Gary. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Music : NSObject

@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *downloadLink;

@end
