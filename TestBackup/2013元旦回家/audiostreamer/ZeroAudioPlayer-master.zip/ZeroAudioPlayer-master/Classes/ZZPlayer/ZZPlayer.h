//
//  ZZPlayer.h
//  ZeroAudioPlayer
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *ZZPlayingTimeNotification;
extern NSString *ZZStopingEOFNotification;

@interface ZZPlayer : NSObject
- (void)play:(NSURL *)aUrl;
- (void)pause;
- (void)stop;
@end
