//
//  ZZPlayer.m
//  ZeroAudioPlayer
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import "ZZPlayer.h"
#import "AudioStreamer.h"
#import <QuartzCore/CoreAnimation.h>
#import <MediaPlayer/MediaPlayer.h>
#import <CFNetwork/CFNetwork.h>

NSString *ZZPlayingTimeNotification = @"ZZPlayingTimeNotification";
NSString *ZZStopingEOFNotification = @"ZZStopingEOFNotification";

@interface ZZPlayer()
{
	AudioStreamer *streamer;
	NSURL *url;
	NSTimer *progressUpdateTimer;
}
@end

@implementation ZZPlayer
- (id)init {
	self = [super init];
	if (self) {
		streamer = nil;
		url = nil;
	}
	return self;
}
- (void)dealloc {
	[[NSNotificationCenter defaultCenter]
		 removeObserver:self
		 name:ASStatusChangedNotification
		 object:streamer
	 ];
	if (progressUpdateTimer) {
		[progressUpdateTimer invalidate];
		progressUpdateTimer = nil;
	}
	[url release], url = nil;
	[streamer release], streamer = nil;
	[super dealloc];
}

- (void)play:(NSURL *)aUrl {
	[url release], url = [aUrl copy];
	[self destroyStreamer];
	[self createStreamer];
	[streamer start];
}
- (void)pause {
	[streamer pause];
}
- (void)stop {
	[self destroyStreamer];
}

#pragma mark -
- (void)destroyStreamer {
	if (streamer != nil) {
		[[NSNotificationCenter defaultCenter]
			 removeObserver:self
			 name:ASStatusChangedNotification
			 object:streamer
		 ];
		
		if (progressUpdateTimer != nil) {
			[progressUpdateTimer invalidate], progressUpdateTimer = nil;
		}
		
		[streamer stop];
		[streamer release], streamer = nil;
	}
}
- (void)createStreamer {
	if (streamer == nil) {
		streamer = [[AudioStreamer alloc] initWithURL:url];
		
		progressUpdateTimer =
		[NSTimer
			 scheduledTimerWithTimeInterval:.9
			 target:self
			 selector:@selector(updateProgress:)
			 userInfo:nil
			 repeats:YES
		 ];
		[[NSNotificationCenter defaultCenter]
			 addObserver:self
			 selector:@selector(playbackStateChanged:)
			 name:ASStatusChangedNotification
			 object:streamer
		 ];
	}
}

#pragma mark - 
- (void)updateProgress:(NSDictionary *)info {
	int progress = (int)streamer.progress;
	int duration = (int)streamer.duration;
	int pro_min = progress/60;
	int pro_sec = progress%60;
	int dur_min = duration/60;
	int dur_sec = duration%60;
	NSDictionary *userInfo = @{
		@"progress_min":@(pro_min),
		@"progress_sec":@(pro_sec),
		@"duration_min":@(dur_min),
		@"duration_sec":@(dur_sec),
		@"percentage":@(streamer.progress/streamer.duration)
	};
	[[NSNotificationCenter defaultCenter]
	 	postNotificationName:ZZPlayingTimeNotification
		object:self
		userInfo:userInfo
	 ];
}
- (BOOL)stoped {
	AudioStreamerState state = streamer.state;
	AudioStreamerStopReason stopReason = streamer.stopReason;
	return (state==AS_STOPPED && stopReason==AS_STOPPING_EOF);
}
- (void)playbackStateChanged:(NSNotification *)notif {
	NSLog(@"state:%d",streamer.state);
	if ([self stoped]) {
		[[NSNotificationCenter defaultCenter]
			 postNotificationName:ZZStopingEOFNotification
			 object:self
			 userInfo:nil
		 ];
	}
}

#pragma mark -
@end
