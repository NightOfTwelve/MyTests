//
//  ViewController.m
//  ZeroAudioPlayer
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import "ViewController.h"
#import "ZZPlayer.h"

@interface ViewController ()
<UITableViewDataSource,UITableViewDelegate>
{
	NSMutableArray *musicList;
	ZZPlayer *player;
	NSUInteger index;
	BOOL playPause;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	NSString *path = [[NSBundle mainBundle] pathForResource:@"MusicList" ofType:@"plist"];
	musicList = [[NSMutableArray alloc] initWithContentsOfFile:path];
	index = 0;
	playPause = NO;
	player = [[ZZPlayer alloc] init];
	
	[[NSNotificationCenter defaultCenter]
		 addObserver:self
		 selector:@selector(updateTimeLabels:)
		 name:ZZPlayingTimeNotification
	 object:nil];
	[[NSNotificationCenter defaultCenter]
		 addObserver:self
		 selector:@selector(onClickedNextButton:)
		 name:ZZStopingEOFNotification
	 object:nil];
}
- (void)updateTimeLabels:(NSNotification *)notif {
	NSDictionary *userInfo = notif.userInfo;
	self.currentTimeLabel.text = [NSString stringWithFormat:@"%02d:%02d",[userInfo[@"progress_min"] intValue],[userInfo[@"progress_sec"] intValue]];
	self.totalTimeLabel.text = [NSString stringWithFormat:@"%02d:%02d",[userInfo[@"duration_min"] intValue],[userInfo[@"duration_sec"] intValue]];
	self.slider.value = [userInfo[@"percentage"] floatValue];
}
- (void)dealloc {
	[player release];
	[musicList release];
    [_tableView release];
    [_slider release];
    [_currentTimeLabel release];
    [_totalTimeLabel release];
    [_playButtonItem release];
	[_playButton release];
    [super dealloc];
}
- (IBAction)sliderTouchUpInside:(UISlider *)sender {
}

- (IBAction)onClickedPlayButton:(UIBarButtonItem *)sender {
	if (playPause) {
		[player pause];
		sender.title = @"Play";
	} else {
		[self playAtIndex:index];
	}
	playPause = !playPause;
	
}

- (IBAction)onClickedNextButton:(UIBarButtonItem *)sender {
	NSLog(@"next");
	index = (index+1)%musicList.count;
	[self playAtIndex:index];
}

- (IBAction)onClickedPreviousButton:(UIBarButtonItem *)sender {
	NSLog(@"previous");
	index = (index+musicList.count-1)%musicList.count;
	[self playAtIndex:index];
}

- (IBAction)onClickedStopButton:(UIBarButtonItem *)sender {
	[player stop];
	index = 0;
	NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index
												 inSection:0];

	[self.tableView deselectRowAtIndexPath:indexPath animated:NO];
	self.playButton.title = @"Play";
}

#pragma mark -
- (NSString *)musicNameAtIndex:(NSUInteger)idx {
	NSDictionary *info = musicList[idx];
	return info[@"name"];
}
- (NSURL *)musicURLAtIndex:(NSUInteger)idx {
	NSDictionary *info = musicList[idx];
	NSURL *url = [NSURL URLWithString:info[@"url"]];
	return url;
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return musicList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"cell_id"];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
									  reuseIdentifier:@"cell_id"]
				autorelease];
	}
	cell.textLabel.text = [self musicNameAtIndex:indexPath.row];
	return cell;
}
#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	index = indexPath.row;
	[self playAtIndex:indexPath.row];
}

#pragma mark -
- (void)playAtIndex:(NSUInteger)idx {
	[player play:[self musicURLAtIndex:idx]];
	NSIndexPath *indexPath = [NSIndexPath indexPathForItem:idx
												 inSection:0];
	[self.tableView selectRowAtIndexPath:indexPath
								animated:NO
						  scrollPosition:UITableViewScrollPositionMiddle];
	self.playButton.title = @"Pause";
}
@end
