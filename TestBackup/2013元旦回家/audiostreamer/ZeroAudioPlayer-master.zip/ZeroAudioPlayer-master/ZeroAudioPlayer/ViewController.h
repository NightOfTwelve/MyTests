//
//  ViewController.h
//  ZeroAudioPlayer
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITableView *tableView;
@property (retain, nonatomic) IBOutlet UISlider *slider;
@property (retain, nonatomic) IBOutlet UILabel *currentTimeLabel;
@property (retain, nonatomic) IBOutlet UILabel *totalTimeLabel;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *playButtonItem;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *playButton;
- (IBAction)sliderTouchUpInside:(UISlider *)sender;
- (IBAction)onClickedPlayButton:(UIBarButtonItem *)sender;
- (IBAction)onClickedNextButton:(UIBarButtonItem *)sender;
- (IBAction)onClickedPreviousButton:(UIBarButtonItem *)sender;
- (IBAction)onClickedStopButton:(UIBarButtonItem *)sender;

@end
