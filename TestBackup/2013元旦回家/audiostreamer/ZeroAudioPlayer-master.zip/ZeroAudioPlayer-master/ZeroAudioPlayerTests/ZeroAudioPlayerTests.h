//
//  ZeroAudioPlayerTests.h
//  ZeroAudioPlayerTests
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface ZeroAudioPlayerTests : SenTestCase

@end
