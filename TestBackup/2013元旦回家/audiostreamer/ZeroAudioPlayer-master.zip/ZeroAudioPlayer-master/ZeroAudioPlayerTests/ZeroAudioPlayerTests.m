//
//  ZeroAudioPlayerTests.m
//  ZeroAudioPlayerTests
//
//  Created by song on 12-12-10.
//  Copyright (c) 2012年 Zero. All rights reserved.
//

#import "ZeroAudioPlayerTests.h"

@implementation ZeroAudioPlayerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ZeroAudioPlayerTests");
}

@end
